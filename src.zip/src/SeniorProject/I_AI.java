package SeniorProject;

public interface I_AI {
}

package SeniorProject;

enum BuildingType {
    SETTLEMENT, CITY;

    @Override
    public String toString() {
        return super.toString();
    }
}